<?php

function emptyInputLogin($NationalIDNumber , $pwd){
    $result;
    if(empty($NationalIDNumber)|| empty($pwd) ){
    $result = true ;
}
else{
    $result = false ;

}
return $result;

}
function uidExists ($conn, $NationalIDNumber,$pwd){
 $sql = "SELECT * FORM employee WHERE NationalIDNumber = ?;";
 $stmt = mysqli_stmt_init($conn);

 if(!mysqli_stmt_prepare($stmt,$sql)){
     header("location : ../login.php?error=stmtfailed");
     exit();

 }

 mysqli_stmt_blid_param($stmt,"ss",$NationalIDNumber,$pwd);
 mysqli_stmt_excute($stmt);

 $resultData = mysqli_stmt_get_result($stmt);
 
 if($row = mysqli_fetch_assoc($resultData)){
return $row;
 }
 else{
     $result = false;
     return $result;
 }
 mysqli_stmt_close($stmt);

}
function loginUser($conn,$NationalIDNumber , $pwd ){

$uidExists = uidExists($conn , $NationalIDNumber , $pwd);

if ($uidExists === false){
header("location: ../login.php?error= wronglogin");
exit();

}

$pwdHashed = $uidExists["password"];
$checkpwd = password_verify($pwd , $pwdHashed);

if ($checkpwd === false){
   header("location: ../login.php?error= wronglogin");
   exit();

}
else if ($checkpwd === true ){
session_start();
$_SESSION["NationalIDNumber"] = $uidExists["NationalIDNumber"];
header("location: ../login.php?error= wronglogin");
exit();


}



}