
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DB Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="s.css">    
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="https://i.postimg.cc/vH2qLBBD/eaab8f1e-0cc6-48b0-988c-871761998c08-200x200.png" >
        </div>
<ul class="nav-area">
<li><a href="index.php">Home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="contact.php">Contact US</a></li>
</ul>
</div>
<div class="welcome-text">
        <h1>
DB <span>Center</span></h1>
<a href="login.php">Log in</a>
    </div>
</header>

</body>
</html>
