

<head>
    <meta charset="UTF-8">
    <title>DB Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="search_css.css">    
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="https://i.postimg.cc/vH2qLBBD/eaab8f1e-0cc6-48b0-988c-871761998c08-200x200.png" >
        </div>
<ul class="nav-area">
<li><a href="index.php">log out</a></li>
<li><a href="login.inc.php">Search</a></li>
<li><a href="about.php">About</a></li>
<li><a href="contact.php">Contact US</a></li>
</ul>
</div>


<div class="login">

        
<a>
<?php

$host = "localhost";
$username = "root";
$user_pass = "usbw";
$database_in_use = "test";

$mysqli = new mysqli($host, $username , $user_pass, $database_in_use);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


$sql = "SELECT NationalIDNumber,Name,Gender,BloodType,Age,Address,HealthRecord,Medicine,MedicineDosages,Balance,CriminalRecord,Criminal_Record,DrivingRecord FROM citizen";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    $Naidnumber =  $row["NationalIDNumber"];
    $name      =  $row["Name"] ;
    $gender    = $row["Gender"] ;
    $bloodtype = $row["BloodType"];
    $age = $row["Age"];
    $address = $row["Address"];
    $herecord = $row["HealthRecord"];
    $med = $row["Medicine"];
    $medd = $row["MedicineDosages"];
    $balance = $row["Balance"];
    $crimreocrd = $row["CriminalRecord"];
     $crimrecordb = false ;
    $drrecord = $row["DrivingRecord"];
  }
} else {
  echo "0 results";
}
$mysqli->close();

 
?>

<table class ="content-table">
<tr><td>NationalIDNumber</td><td><?php   echo $Naidnumber ?> </td></tr>
<tr><td>Name</td><td><?php   echo $name ?> </td></tr>
<tr><td>Gender</td><td><?php   echo $gender ?> </td></tr>
<tr><td>BloodType</td><td><?php   echo $bloodtype ?> </td></tr>
<tr><td>age</td><td><?php   echo $age ?> </td></tr>
<tr><td>address</td><td><?php   echo $address ?> </td></tr>
<tr><td>HealthRecord</td><td><?php   echo $herecord ?> </td></tr>
<tr><td>Medicine</td><td><?php   echo $med ?> </td></tr>
<tr><td>MedicineDosages</td><td><?php   echo $medd ?> </td></tr>
<tr><td>Balance</td><td><?php   echo $balance ?> </td></tr>
<tr><td>CriminalRecord</td><td><?php   echo $crimrecordb ?> </td></tr>
<tr><td>CriminalRecord</td><td><?php   echo $crimreocrd ?> </td></tr>
<tr><td>DrivingRecord</td><td><?php   echo $drrecord ?> </td></tr>
</table>




</a>

    </div>
</header>

</body>


