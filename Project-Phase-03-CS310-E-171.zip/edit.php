
<?php

$host = "localhost";
$username = "root";
$user_pass = "usbw";
$database_in_use = "test";

$mysqli = new mysqli($host, $username , $user_pass, $database_in_use);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
echo $mysqli->host_info . "\n";

$sql = "SELECT NationalIDNumber,Name,Gender,Password,BloodType,Age,Address,HealthRecord,Medicine,MedicineDosages,Balance,CriminalRecord,Criminal_Record,DrivingRecord FROM citizen";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    echo "<br>"."NationalIDNumber: " . $row["NationalIDNumber"]. " - Name: ".$row["Name"] . " - Gender : ".$row["Gender"] . " - BloodType :".$row["BloodType"]. " - Age :".$row["Age"]." - Address".$row["Address"]." - HealthRecord :".$row["HealthRecord"]." - Medicine :".$row["Medicine"]." - MedicineDosages :".$row["MedicineDosages"]." - Balance :".$row["Balance"]." - CriminalRecord :".$row["CriminalRecord"]." - Criminal_Record :".$row["Criminal_Record"]." - DrivingRecord :".$row["DrivingRecord"]. "<br>";
  }
} else {
  echo "0 results";
}
$mysqli->close();


?>