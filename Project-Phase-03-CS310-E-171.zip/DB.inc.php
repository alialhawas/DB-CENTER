<?php

$host = "localhost";
$username = "root";
$user_pass = "usbw";
$database_in_use = "test";

$conn = mysqli_connect($host,$username,$user_pass,$database_in_use);

if(!$conn){
die("connection failed: " . mysqli_connect_error()) ;
}

